echo "welcome to the trash clonner (aka trash on desktop) you will see a trash file on your desktop drag the startthetrash.q file into the trash file on your desktop";
ln -s ~/.Trash ~/Desktop/Trash
echo "making the trash file on your desktop........... ";
Echo "Please wait........................................................................................................................................................................................................................................................................................................................................................................................................";
/Users/lucaspetrino/Trash\ Cloneer/dodot.js 
echo "Done!"; 